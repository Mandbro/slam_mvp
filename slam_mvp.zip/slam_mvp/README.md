# SLAM Multi-Agent AutoTune MVP

## 功能

- ROS2 rosbag 回放
- TF 自动检测
- 地图质量分析
- GPT 自动调参
- YAML 自动修改
- 自动生成报告

## 环境

- Ubuntu 22.04
- ROS2 Humble
- Python 3.10

## 安装

```bash
pip install -r requirements.txt
```

## 运行

```bash
chmod +x start.sh
./start.sh
```
