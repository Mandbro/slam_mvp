from agents.tf_agent import TFAgent
from agents.map_agent import MapAgent
from agents.parameter_agent import ParameterAgent

from core.yaml_editor import YAMLEditor
from core.ros_runner import ROSRunner


class SLAMMVP:

    def __init__(self):

        self.tf_agent = TFAgent()

        self.map_agent = MapAgent()

        self.param_agent = ParameterAgent()

        self.yaml_editor = YAMLEditor()

        self.runner = ROSRunner()

    def run(self):

        print("===== 启动SLAM MVP =====")

        self.runner.launch_slam()

        self.runner.play_bag(
            "bags/test_bag"
        )

        tf_result = self.tf_agent.check()

        print(tf_result)

        map_result = self.map_agent.evaluate(
            "map.pgm"
        )

        print("地图质量结果:")
        print(map_result)

        tuning = self.param_agent.optimize(
            map_result
        )

        print("LLM调参建议:")
        print(tuning)

        self.yaml_editor.update(
            "configs/fastlio.yaml",
            "output/tuned_fastlio.yaml",
            "voxel_size",
            0.2
        )

        with open("output/report.txt", "w") as f:
            f.write(str(map_result))
            f.write("\n\n")
            f.write(tuning)

        print("===== MVP运行结束 =====")


if __name__ == '__main__':

    app = SLAMMVP()

    app.run()
