import cv2
import numpy as np

class MapAgent:

    def evaluate(self, map_path):

        img = cv2.imread(map_path, 0)

        blur = cv2.Laplacian(
            img,
            cv2.CV_64F
        ).var()

        occupied = np.sum(img < 100)

        ratio = occupied / img.size

        score = blur * ratio

        return {
            "sharpness": float(blur),
            "occupied_ratio": float(ratio),
            "score": float(score)
        }
