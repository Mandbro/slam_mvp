import subprocess

class TFAgent:

    def check(self):

        print("开始检查TF树...")

        cmd = [
            "ros2",
            "run",
            "tf2_tools",
            "view_frames"
        ]

        subprocess.run(cmd)

        return "TF检查完成"
