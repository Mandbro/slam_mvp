from core.llm_client import LLMClient

class ParameterAgent:

    def __init__(self):
        self.llm = LLMClient()

    def optimize(self, diagnostics):

        prompt = f"""
你是FAST-LIO专家。

以下是地图质量分析结果：

{diagnostics}

请给出：
1. 建议修改参数
2. 推荐值
3. 修改原因
"""

        return self.llm.ask(prompt)
