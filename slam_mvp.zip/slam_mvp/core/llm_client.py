from openai import OpenAI

class LLMClient:

    def __init__(self):

        self.client = OpenAI(
            api_key="YOUR_API_KEY"
        )

    def ask(self, prompt):

        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        return response.choices[0].message.content
