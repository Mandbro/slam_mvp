import subprocess
import time

class ROSRunner:

    def play_bag(self, bag_path):

        cmd = [
            "ros2",
            "bag",
            "play",
            bag_path
        ]

        subprocess.Popen(cmd)

    def launch_slam(self):

        cmd = [
            "ros2",
            "launch",
            "fast_lio",
            "mapping.launch.py"
        ]

        subprocess.Popen(cmd)

        time.sleep(10)
