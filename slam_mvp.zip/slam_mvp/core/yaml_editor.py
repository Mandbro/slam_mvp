import yaml

class YAMLEditor:

    def update(self,
               input_yaml,
               output_yaml,
               key,
               value):

        with open(input_yaml, 'r') as f:
            data = yaml.safe_load(f)

        data[key] = value

        with open(output_yaml, 'w') as f:
            yaml.dump(data, f)
